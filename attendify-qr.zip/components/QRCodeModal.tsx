
import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Printer } from 'lucide-react';
import { Student } from '../types';

interface QRCodeModalProps {
  student: Student;
  onClose: () => void;
}

const QRCodeModal: React.FC<QRCodeModalProps> = ({ student, onClose }) => {
  const printQR = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center relative print:shadow-none print:p-0">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 print:hidden"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="print:block">
          <h3 className="text-xl font-bold mb-1">{student.name}</h3>
          <p className="text-slate-500 mb-6 font-mono">Reg: {student.registerNumber}</p>
          
          <div className="bg-white p-4 border rounded-xl inline-block mb-6 shadow-sm">
            <QRCodeSVG 
              value={`ATTENDIFY:${student.id}`} 
              size={200}
              level="H"
              includeMargin={true}
            />
          </div>
        </div>

        <button
          onClick={printQR}
          className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white py-3 rounded-xl font-semibold hover:bg-indigo-700 transition-colors print:hidden"
        >
          <Printer className="w-5 h-5" />
          Print ID Code
        </button>
      </div>
    </div>
  );
};

export default QRCodeModal;
