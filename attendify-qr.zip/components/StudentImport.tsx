
import React, { useState } from 'react';
import { Upload, FileText, Loader2, CheckCircle2 } from 'lucide-react';
import { extractStudentsFromPdf } from '../services/geminiService';

interface StudentImportProps {
  onImport: (students: { name: string, registerNumber: string }[]) => void;
}

const StudentImport: React.FC<StudentImportProps> = ({ onImport }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      setError("Please upload a PDF file.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const students = await extractStudentsFromPdf(file);
      if (students && students.length > 0) {
        onImport(students);
      } else {
        setError("Could not find student data in this PDF. Please try a different format.");
      }
    } catch (err) {
      setError("AI analysis failed. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 border-2 border-dashed border-slate-200 rounded-2xl bg-white hover:border-indigo-300 transition-colors">
      <div className="flex flex-col items-center text-center">
        {loading ? (
          <div className="py-8">
            <Loader2 className="w-12 h-12 text-indigo-500 animate-spin mb-4 mx-auto" />
            <p className="text-slate-600 font-medium">AI is reading your PDF...</p>
            <p className="text-slate-400 text-sm">Identifying student names and register numbers</p>
          </div>
        ) : (
          <>
            <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mb-4">
              <Upload className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-1">Import Student Roster</h3>
            <p className="text-slate-500 text-sm mb-6 max-w-xs">Upload your class PDF register. Our AI will automatically extract student data.</p>
            
            <label className="cursor-pointer bg-slate-900 text-white px-6 py-3 rounded-xl font-semibold hover:bg-slate-800 transition-all shadow-md active:scale-95 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Choose PDF File
              <input 
                type="file" 
                className="hidden" 
                accept=".pdf"
                onChange={handleFileChange}
              />
            </label>

            {error && <p className="mt-4 text-red-500 text-sm font-medium">{error}</p>}
          </>
        )}
      </div>
    </div>
  );
};

export default StudentImport;
