
import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X, Zap, UserCheck, ShieldCheck } from 'lucide-react';

interface ScannerOverlayProps {
  onScan: (studentId: string) => void;
  onClose: () => void;
  scannedNames: string[]; // Pass names instead of just IDs for feedback
}

const ScannerOverlay: React.FC<ScannerOverlayProps> = ({ onScan, onClose, scannedNames }) => {
  const [cameraReady, setCameraReady] = useState(false);
  const [lastScanned, setLastScanned] = useState<string | null>(null);
  const qrScannerRef = useRef<Html5Qrcode | null>(null);
  const cooldownRef = useRef<Record<string, number>>({});

  useEffect(() => {
    const startScanner = async () => {
      try {
        const html5QrCode = new Html5Qrcode("qr-reader-core");
        qrScannerRef.current = html5QrCode;

        await html5QrCode.start(
          { facingMode: "environment" },
          {
            fps: 20, // High FPS for rapid "Plickers-style" room scanning
            qrbox: { width: 280, height: 280 },
            aspectRatio: 1.0
          },
          (decodedText) => {
            if (decodedText.startsWith('ATTENDIFY:')) {
              const studentId = decodedText.split(':')[1];
              const now = Date.now();
              
              // 2-second cooldown per specific student to avoid multi-triggering
              // but allows other students to be scanned immediately (Bulk mode)
              if (!cooldownRef.current[studentId] || now - cooldownRef.current[studentId] > 2000) {
                cooldownRef.current[studentId] = now;
                onScan(studentId);
                setLastScanned(studentId);
                
                // Haptic feedback if available
                if (window.navigator.vibrate) window.navigator.vibrate(50);
              }
            }
          },
          () => {} 
        );
        setCameraReady(true);
      } catch (err) {
        console.error("Scanner startup failed", err);
        onClose();
      }
    };

    startScanner();

    return () => {
      if (qrScannerRef.current) {
        qrScannerRef.current.stop().catch(console.error);
      }
    };
  }, [onScan, onClose]);

  return (
    <div className="fixed inset-0 bg-slate-950 z-[100] flex flex-col items-center justify-between p-6">
      <div className="w-full flex justify-between items-center text-white">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500 rounded-lg animate-pulse">
            <Zap className="w-5 h-5 text-white fill-white" />
          </div>
          <div>
            <h2 className="font-bold text-lg">Room Scan Mode</h2>
            <p className="text-slate-400 text-xs">Pan camera across the room</p>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all active:scale-90"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="relative w-full max-w-sm aspect-square my-4">
        <div id="qr-reader-core" className="w-full h-full overflow-hidden border-4 border-indigo-500/30 rounded-[2.5rem] bg-black shadow-2xl shadow-indigo-500/20"></div>
        
        {/* Animated Scan Frame */}
        <div className="absolute inset-0 border-[2px] border-indigo-400/50 rounded-[2.5rem] animate-pulse pointer-events-none"></div>
        
        {!cameraReady && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900 rounded-[2.5rem]">
            <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}

        {/* Floating Success Indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-none">
          {scannedNames.length > 0 && (
            <div className="bg-emerald-500 text-white px-4 py-2 rounded-full font-bold shadow-xl flex items-center gap-2 animate-bounce">
              <ShieldCheck className="w-4 h-4" />
              Detected {scannedNames[scannedNames.length - 1]}
            </div>
          )}
        </div>
      </div>

      <div className="w-full max-w-md bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5 overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Live Feed Log</h3>
          <span className="bg-indigo-500 text-white text-[10px] font-bold px-2 py-0.5 rounded">
            {scannedNames.length} SCANNED
          </span>
        </div>
        <div className="flex flex-col gap-2 max-h-32 overflow-y-auto pr-2 custom-scrollbar">
          {scannedNames.length === 0 ? (
            <p className="text-slate-600 text-sm italic text-center py-4">Scanning for student codes...</p>
          ) : (
            [...scannedNames].reverse().map((name, i) => (
              <div key={i} className="flex items-center justify-between bg-white/10 p-3 rounded-xl border border-white/5 animate-in slide-in-from-right-4 duration-300">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center">
                    <UserCheck className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-white font-medium text-sm">{name}</span>
                </div>
                <span className="text-emerald-400 text-[10px] font-bold">SUCCESS</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default ScannerOverlay;
