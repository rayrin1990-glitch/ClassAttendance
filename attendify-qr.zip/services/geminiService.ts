
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const extractStudentsFromPdf = async (file: File): Promise<{ registerNumber: string, name: string, visualDescription?: string }[]> => {
  const base64Data = await new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1]);
    };
    reader.readAsDataURL(file);
  });

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'application/pdf',
            data: base64Data,
          },
        },
        {
          text: `Extract student roster. For each student, find 'registerNumber' and 'name'. 
          IMPORTANT: If there is a photo of the student, provide a 3-4 word 'visualDescription' (e.g., 'male, glasses, short hair', 'female, curly hair'). 
          Return as JSON array.`
        }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            registerNumber: { type: Type.STRING },
            name: { type: Type.STRING },
            visualDescription: { type: Type.STRING, description: "Short visual traits from the photo if present" }
          },
          required: ["registerNumber", "name"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    return [];
  }
};

export const generateClassSummary = async (classData: any): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Analyze this classroom data and write a professional, inspiring end-of-year summary report for a teacher. 
    Class: ${classData.name}. 
    Data: ${JSON.stringify(classData.students)}.
    
    Format the report with these sections:
    1. Overall Class Performance & Attendance Trends.
    2. Engagement Highlights (mention specific top contributors).
    3. Areas of Growth & Observations.
    4. Concluding encouraging remark.
    
    Use a professional and supportive tone.`,
    config: {
      thinkingConfig: { thinkingBudget: 2000 }
    }
  });

  return response.text || "Failed to generate summary.";
};
