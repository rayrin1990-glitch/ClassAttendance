
import React, { useState, useEffect } from 'react';
import { 
  Users, Plus, QrCode, Trash2, ChevronRight, ArrowLeft, 
  CheckCircle, Circle, Camera, Calendar, BookOpen, Search, 
  LayoutGrid, History, Star, MessageSquare, Presentation, Lightbulb,
  FileText, Sparkles, X, Download, Copy, Loader2
} from 'lucide-react';
import { ClassSession, Student, Participation } from './types';
import StudentImport from './components/StudentImport';
import QRCodeModal from './components/QRCodeModal';
import ScannerOverlay from './components/ScannerOverlay';
import { generateClassSummary } from './services/geminiService';

type ViewMode = 'roster' | 'history' | 'participation';

const App: React.FC = () => {
  const [classes, setClasses] = useState<ClassSession[]>([]);
  const [activeClassId, setActiveClassId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('roster');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [scannedNames, setScannedNames] = useState<string[]>([]);
  
  // Summary States
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [summaryText, setSummaryText] = useState<string | null>(null);

  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    const saved = localStorage.getItem('attendify_classes_v4');
    if (saved) setClasses(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('attendify_classes_v4', JSON.stringify(classes));
  }, [classes]);

  const createClass = () => {
    if (!newClassName.trim()) return;
    const newClass: ClassSession = {
      id: Date.now().toString(),
      name: newClassName,
      students: [],
      createdAt: new Date().toISOString(),
      attendanceDates: [today]
    };
    setClasses([...classes, newClass]);
    setNewClassName('');
    setShowCreateModal(false);
  };

  const deleteClass = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm("Delete this class and all historical data?")) {
      setClasses(classes.filter(c => c.id !== id));
      if (activeClassId === id) setActiveClassId(null);
    }
  };

  const handleImportedStudents = (imported: { name: string, registerNumber: string, visualDescription?: string }[]) => {
    if (!activeClassId) return;
    setClasses(prev => prev.map(c => {
      if (c.id === activeClassId) {
        const newStudents: Student[] = imported.map(s => ({
          id: Math.random().toString(36).substr(2, 9),
          name: s.name,
          registerNumber: s.registerNumber,
          visualDescription: s.visualDescription,
          // Use visual description + name for more accurate avatar seed
          avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(s.visualDescription || s.name)}&backgroundColor=b6e3f4,c0aede,d1d4f9`,
          isPresent: false,
          attendanceHistory: {},
          participation: { askingQuestions: 0, presentingSolutions: 0, answeringQuestions: 0 }
        }));
        return { ...c, students: [...c.students, ...newStudents] };
      }
      return c;
    }));
  };

  const activeClass = classes.find(c => c.id === activeClassId);

  const handleGenerateSummary = async () => {
    if (!activeClass) return;
    setIsGeneratingSummary(true);
    try {
      const report = await generateClassSummary(activeClass);
      setSummaryText(report);
    } catch (err) {
      alert("Failed to generate summary. Please try again.");
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  const toggleAttendance = (studentId: string, date: string = today) => {
    setClasses(prev => prev.map(c => {
      if (c.id === activeClassId) {
        if (!c.attendanceDates.includes(date)) c.attendanceDates.push(date);
        return {
          ...c,
          students: c.students.map(s => s.id === studentId ? {
            ...s,
            attendanceHistory: { ...s.attendanceHistory, [date]: !(s.attendanceHistory[date] || false) }
          } : s)
        };
      }
      return c;
    }));
  };

  const handleParticipation = (studentId: string, type: keyof Participation) => {
    setClasses(prev => prev.map(c => {
      if (c.id === activeClassId) {
        return {
          ...c,
          students: c.students.map(s => s.id === studentId ? { 
            ...s, 
            participation: { ...s.participation, [type]: s.participation[type] + 1 } 
          } : s)
        };
      }
      return c;
    }));
  };

  const handleScan = (studentId: string) => {
    setClasses(prev => prev.map(c => {
      if (c.id === activeClassId) {
        const student = c.students.find(s => s.id === studentId);
        if (student && !student.attendanceHistory[today]) {
          setScannedNames(prev => [...prev, student.name]);
          if (!c.attendanceDates.includes(today)) c.attendanceDates.push(today);
          return {
            ...c,
            students: c.students.map(s => s.id === studentId ? { 
              ...s, 
              attendanceHistory: { ...s.attendanceHistory, [today]: true } 
            } : s)
          };
        }
      }
      return c;
    }));
  };

  const filteredStudents = activeClass?.students.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.registerNumber.toLowerCase().includes(searchQuery.toLowerCase())
  ).sort((a, b) => a.name.localeCompare(b.name)) || [];

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <header className="bg-white border-b sticky top-0 z-40 px-8 py-5 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg ring-4 ring-indigo-50">
            <Users className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight text-slate-900 leading-none">Attendify<span className="text-indigo-600">PRO</span></h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Classroom AI Suite</p>
          </div>
        </div>
        
        {activeClassId && (
          <div className="flex gap-3">
             <button 
                onClick={handleGenerateSummary}
                disabled={isGeneratingSummary || activeClass.students.length === 0}
                className="flex items-center gap-2 bg-white border-2 border-slate-100 text-slate-900 px-5 py-2.5 rounded-xl font-bold hover:bg-slate-50 transition-all shadow-sm active:scale-95 disabled:opacity-50"
              >
                {isGeneratingSummary ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4 text-amber-500" />}
                Summary
              </button>
              <button 
                onClick={() => setIsScannerOpen(true)}
                className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg active:scale-95"
              >
                <Camera className="w-5 h-5" />
                <span>Bulk Scan</span>
              </button>
          </div>
        )}
      </header>

      <main className="max-w-7xl mx-auto p-8">
        {!activeClassId ? (
          <section>
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-black text-slate-900">Your Campus</h2>
              <button onClick={() => setShowCreateModal(true)} className="bg-slate-900 text-white px-6 py-3 rounded-2xl font-bold shadow-xl">
                <Plus className="w-5 h-5 inline mr-2" /> New Class
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {classes.map(c => (
                <div key={c.id} onClick={() => setActiveClassId(c.id)} className="group bg-white p-8 rounded-[2rem] border-2 border-transparent hover:border-indigo-100 cursor-pointer transition-all hover:shadow-xl relative">
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-14 h-14 bg-slate-100 group-hover:bg-indigo-600 rounded-2xl flex items-center justify-center text-slate-400 group-hover:text-white transition-all shadow-sm">
                      <BookOpen className="w-7 h-7" />
                    </div>
                    <button onClick={(e) => deleteClass(c.id, e)} className="p-2 text-slate-300 hover:text-red-500"><Trash2 className="w-5 h-5" /></button>
                  </div>
                  <h3 className="text-xl font-black text-slate-900 mb-2">{c.name}</h3>
                  <div className="flex gap-4 mt-6 text-sm font-bold text-slate-500">
                    <span className="bg-slate-50 px-3 py-1 rounded-lg">Students: {c.students.length}</span>
                    <span className="bg-slate-50 px-3 py-1 rounded-lg">Days: {c.attendanceDates.length}</span>
                  </div>
                </div>
              ))}
              {classes.length === 0 && <div className="col-span-full py-20 text-center text-slate-400 font-bold">No classes created yet.</div>}
            </div>
          </section>
        ) : (
          <section>
            <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <button onClick={() => setActiveClassId(null)} className="text-slate-400 font-black text-[10px] uppercase tracking-widest mb-4 flex items-center gap-1"><ArrowLeft className="w-3 h-3" /> Back to dashboard</button>
                <h2 className="text-4xl font-black text-slate-900">{activeClass?.name}</h2>
                <div className="flex gap-2 mt-6 bg-slate-200/40 p-1.5 rounded-2xl w-fit">
                    {[
                      { id: 'roster', icon: Users, label: 'Roster' },
                      { id: 'history', icon: History, label: 'History' },
                      { id: 'participation', icon: Star, label: 'Engagement' }
                    ].map(tab => (
                      <button 
                        key={tab.id}
                        onClick={() => setViewMode(tab.id as ViewMode)}
                        className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all ${
                          viewMode === tab.id ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                </div>
              </div>
              <div className="relative md:w-80">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                <input 
                  type="text" placeholder="Search student..." value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-6 py-4 bg-white border border-slate-200 rounded-[1.25rem] outline-none font-medium"
                />
              </div>
            </div>

            {activeClass?.students.length === 0 ? (
              <StudentImport onImport={handleImportedStudents} />
            ) : (
              <div className="bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden shadow-sm">
                {viewMode === 'roster' && (
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400">
                      <tr>
                        <th className="px-8 py-5">Photo</th>
                        <th className="px-8 py-5">Register</th>
                        <th className="px-8 py-5">Name</th>
                        <th className="px-8 py-5 text-center">Identity</th>
                        <th className="px-8 py-5 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredStudents.map(student => (
                        <tr key={student.id} className="hover:bg-slate-50/50 group">
                          <td className="px-8 py-5">
                             <div className="w-12 h-12 rounded-2xl overflow-hidden bg-indigo-50 border-2 border-white shadow-sm ring-1 ring-slate-100">
                                <img src={student.avatarUrl} className="w-full h-full object-cover" title={student.visualDescription} />
                             </div>
                          </td>
                          <td className="px-8 py-5 font-mono text-xs font-bold text-slate-400">{student.registerNumber}</td>
                          <td className="px-8 py-5 font-bold text-slate-900">{student.name}</td>
                          <td className="px-8 py-5">
                            <button onClick={() => setSelectedStudent(student)} className="mx-auto block p-3 text-indigo-400 hover:text-indigo-600 transition-colors">
                              <QrCode className="w-6 h-6" />
                            </button>
                          </td>
                          <td className="px-8 py-5">
                            <button 
                              onClick={() => toggleAttendance(student.id)}
                              className={`mx-auto flex items-center gap-2 px-5 py-2 rounded-xl text-[10px] font-black border transition-all ${
                                student.attendanceHistory[today] ? 'bg-emerald-500 text-white border-transparent' : 'bg-white text-slate-300 border-slate-100'
                              }`}
                            >
                              {student.attendanceHistory[today] ? 'PRESENT' : 'MARK'}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {viewMode === 'history' && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left table-fixed">
                      <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b border-slate-100">
                        <tr>
                          <th className="px-8 py-5 w-64 bg-slate-50 sticky left-0 z-10">Student</th>
                          {activeClass.attendanceDates.map(date => <th key={date} className="px-4 py-5 w-32 text-center">{date}</th>)}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredStudents.map(student => (
                          <tr key={student.id}>
                            <td className="px-8 py-5 bg-white sticky left-0 z-10 border-r border-slate-100 font-bold text-sm">{student.name}</td>
                            {activeClass.attendanceDates.map(date => (
                              <td key={date} className="px-4 py-5 text-center">
                                <button onClick={() => toggleAttendance(student.id, date)}>
                                  {student.attendanceHistory[date] ? <CheckCircle className="w-5 h-5 text-emerald-500 mx-auto" /> : <Circle className="w-5 h-5 text-slate-100 mx-auto" />}
                                </button>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {viewMode === 'participation' && (
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      <tr>
                        <th className="px-8 py-5">Name</th>
                        <th className="px-8 py-5 text-center">Inquiry</th>
                        <th className="px-8 py-5 text-center">Solutions</th>
                        <th className="px-8 py-5 text-center">Answering</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredStudents.map(student => (
                        <tr key={student.id}>
                          <td className="px-8 py-5 font-bold">{student.name}</td>
                          <td className="px-8 py-5">
                            <div className="flex items-center justify-center gap-2">
                              <span className="text-xl font-black text-indigo-600 w-8 text-center">{student.participation.askingQuestions}</span>
                              <button onClick={() => handleParticipation(student.id, 'askingQuestions')} className="p-2 bg-indigo-50 text-indigo-600 rounded-lg"><MessageSquare className="w-4 h-4" /></button>
                            </div>
                          </td>
                          <td className="px-8 py-5">
                            <div className="flex items-center justify-center gap-2">
                              <span className="text-xl font-black text-emerald-600 w-8 text-center">{student.participation.presentingSolutions}</span>
                              <button onClick={() => handleParticipation(student.id, 'presentingSolutions')} className="p-2 bg-emerald-50 text-emerald-600 rounded-lg"><Presentation className="w-4 h-4" /></button>
                            </div>
                          </td>
                          <td className="px-8 py-5">
                            <div className="flex items-center justify-center gap-2">
                              <span className="text-xl font-black text-amber-600 w-8 text-center">{student.participation.answeringQuestions}</span>
                              <button onClick={() => handleParticipation(student.id, 'answeringQuestions')} className="p-2 bg-amber-50 text-amber-600 rounded-lg"><Lightbulb className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}
          </section>
        )}
      </main>

      {/* Summary Modal */}
      {summaryText && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-[110] p-6">
          <div className="bg-white rounded-[2.5rem] p-10 max-w-2xl w-full shadow-2xl animate-in zoom-in duration-300 max-h-[85vh] flex flex-col">
            <div className="flex justify-between items-center mb-6">
               <h3 className="text-2xl font-black flex items-center gap-2"><Sparkles className="w-6 h-6 text-amber-500" /> Class Engagement Report</h3>
               <button onClick={() => setSummaryText(null)} className="p-2 text-slate-400 hover:text-slate-900"><X className="w-6 h-6" /></button>
            </div>
            <div className="flex-1 overflow-y-auto pr-2 mb-8 prose prose-slate max-w-none">
               <div className="whitespace-pre-wrap font-medium text-slate-700 leading-relaxed text-sm">{summaryText}</div>
            </div>
            <div className="flex gap-4">
               <button onClick={() => {navigator.clipboard.writeText(summaryText); alert("Report copied to clipboard!");}} className="flex-1 border-2 border-slate-100 font-bold py-3 rounded-2xl flex items-center justify-center gap-2 hover:bg-slate-50 transition-all"><Copy className="w-4 h-4" /> Copy Text</button>
               <button onClick={() => {
                 const blob = new Blob([summaryText], { type: 'text/plain' });
                 const url = URL.createObjectURL(blob);
                 const a = document.createElement('a');
                 a.href = url;
                 a.download = `${activeClass?.name}_AI_Summary.txt`;
                 a.click();
               }} className="flex-1 bg-slate-900 text-white font-bold py-3 rounded-2xl flex items-center justify-center gap-2 hover:bg-slate-800 transition-all shadow-lg"><Download className="w-4 h-4" /> Save Report</button>
            </div>
          </div>
        </div>
      )}

      {/* Other modals remain same as previous version */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-[100] p-6">
          <div className="bg-white rounded-[2.5rem] p-10 max-w-md w-full shadow-2xl animate-in zoom-in duration-300">
            <h3 className="text-3xl font-black mb-2">New Section</h3>
            <input 
              type="text" autoFocus placeholder="e.g. Science - Block A" value={newClassName}
              onChange={(e) => setNewClassName(e.target.value)}
              className="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-indigo-500 outline-none mb-8 text-xl font-bold"
              onKeyPress={(e) => e.key === 'Enter' && createClass()}
            />
            <div className="flex gap-4">
              <button onClick={() => setShowCreateModal(false)} className="flex-1 px-6 py-4 font-black text-slate-400 hover:text-slate-900 transition-colors">CANCEL</button>
              <button onClick={createClass} className="flex-1 bg-indigo-600 text-white px-6 py-4 rounded-2xl font-black shadow-xl">CREATE</button>
            </div>
          </div>
        </div>
      )}

      {selectedStudent && <QRCodeModal student={selectedStudent} onClose={() => setSelectedStudent(null)} />}
      {isScannerOpen && <ScannerOverlay onScan={handleScan} onClose={() => {setIsScannerOpen(false); setScannedNames([]);}} scannedNames={scannedNames} />}
    </div>
  );
};

export default App;
