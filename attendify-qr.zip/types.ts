
export interface Participation {
  askingQuestions: number;
  presentingSolutions: number;
  answeringQuestions: number;
}

export interface Student {
  id: string;
  registerNumber: string;
  name: string;
  avatarUrl?: string;
  visualDescription?: string; // AI's description of the photo in the PDF
  isPresent: boolean;
  attendanceHistory: Record<string, boolean>;
  participation: Participation;
  lastAttended?: string;
}

export interface ClassSession {
  id: string;
  name: string;
  students: Student[];
  createdAt: string;
  attendanceDates: string[];
}
